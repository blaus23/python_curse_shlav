def check_reference(line):
    if line[0] == ">":
        if (line[1:]).isdigit() or (line[1] == " " and (line[2:]).isdigit()):
            return True
    return False