How to use:

- first, clone the project to your linux server

- second, run the deployment playbook (this will make your server compitable with running the application)

- and in the end run the app.py script and the app is now running on your server


Notes:

- run this app only on centos7/8 or rhel7/8 with the root user 

- ansible and git is needed on the server

- have fun! :)

