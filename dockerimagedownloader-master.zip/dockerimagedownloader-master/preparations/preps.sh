#!/bin/bash

# Dissable the firewalld service and the selinux to avoid future problems
systemctl stop firewalld
systemctl disable firewalld
setenforce 0

# Install the epel-release repository
yum install -y epel-release

# Configure yum to install docker 
yum install -y yum-utils device-mapper-persistent-data lvm2 --skip-broken
yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo

# Install, start and enable the docker service
yum install -y docker --skip-broken
systemctl start docker
systemctl enable docker

# Install python 3 and flask module
yum install -y python3
pip3 install flask

# Install openssl (for the ssl/tls cnnection), vim and htop
yum install -y openssl vim htop

# Generate self-signed ssl certificate
openssl req -x509 -newkey rsa:4096 -nodes -out ../ssl/cert.pem -keyout ../ssl/key.pem -days 365 -subj "/C=US/ST=New York/L=New York/O=General Org/OU=Non of your buisness/CN=example.com"



